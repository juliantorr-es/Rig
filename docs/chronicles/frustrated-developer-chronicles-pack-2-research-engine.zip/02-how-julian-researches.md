# 02 — How Julian Researches

Julian’s research style is not casual browsing dressed up as productivity. It is closer to building a private technical intelligence system out of whatever materials are available: papers, videos, docs, transcripts, source code, CLI experiments, benchmark outputs, architecture notes, and painful failed attempts.

The pattern usually looks like this:

A question starts practical. Something is broken, missing, slow, confusing, or architecturally suspicious.

Then it expands. Instead of only asking, “How do I patch this?” Julian asks, “What is the underlying class of problem?” That shift matters. A broken test becomes a question about authority boundaries. A messy CLI becomes a question about command seams. A confusing UI becomes a question about projection ownership. An agent mistake becomes a question about governance, receipts, and write gates.

The research then moves across layers.

There is the surface layer: blog posts, videos, docs, examples, and quick explanations.

There is the engineering layer: source code, implementation details, API boundaries, runtime behavior, build systems, dependency graphs, benchmarks, and failure modes.

There is the governance layer: what should be allowed to mutate state, what counts as evidence, what needs a receipt, what is advisory versus authoritative, and what should be deterministic.

There is the translation layer: turning external knowledge into local project doctrine.

That last layer is the key. Julian does not research just to know more. He researches to produce architecture.

A useful idea does not stay abstract for long. It becomes a validator, a schema, a proof artifact, a receipt format, a projection model, a mission prompt, or a CLI command. Research becomes code. Code produces evidence. Evidence becomes process. Process becomes product.

This is why the work can look obsessive from the outside. The goal is not merely to understand. The goal is to make understanding executable.

That is the method:

Find the pattern.  
Name the authority.  
Define the contract.  
Build the smallest reproducible proof.  
Make the proof visible.  
Then use the proof to decide what gets trusted next.
