# 05 — Valuable YouTubers and Educators

This file names creators and educators who fit Julian’s technical learning style: people who help build mental models, explain systems, connect research to practice, or make hard topics feel less sealed off.

## CodeEmporium

CodeEmporium is valuable for systems-oriented explanations. The strength is not just “here is a concept,” but “here is how pieces fit together.” That makes the channel useful for someone trying to understand compilers, ML systems, language internals, or architecture through connected concepts instead of isolated facts.

For Julian’s work, this style matters because Anigma and Rig are not single-feature projects. They are systems made of contracts, validators, projections, runtimes, authority boundaries, and developer workflows. Explanations that show structure are more useful than trivia.

## AI Coffee Break with Letitia

AI Coffee Break with Letitia is useful as a research-adjacent bridge. It helps turn dense AI topics into understandable conceptual maps without requiring the learner to already be deep inside the literature.

That kind of bridge is important when the goal is not to become a pure ML theorist, but to understand enough about AI systems to design tools around them: agents, retrieval, evaluation, governance, model behavior, failure modes, and workflow integration.

## Yannic Kilcher

Yannic Kilcher is valuable for paper-heavy AI learning. The channel is useful when Julian wants to move beyond simplified explanations and get closer to how research papers are structured, argued, and implemented.

This matters because Julian’s research style often needs the actual idea underneath the hype. A paper walkthrough can reveal what a method really claims, what it assumes, what it measures, and what parts are likely to matter in real engineering work.

## Sebastian Bubeck

Sebastian Bubeck is useful for higher-level AI research framing. The value is in serious conceptual orientation around what frontier systems may be doing, how capabilities emerge, and how researchers think about intelligence, reasoning, and model behavior.

For Julian, that kind of framing helps connect product design to the larger research landscape without getting trapped in shallow AI discourse.

## Acerola

Acerola is valuable for taste, systems intuition, graphics thinking, optimization culture, and the joy of deeply explaining a technical topic with style. Even when the topic is not directly LLMs or RAG, the approach is relevant: visual intuition, performance awareness, technical storytelling, and craft.

Acerola’s value is also aesthetic. For someone building native software and caring about interface, materiality, and computational efficiency, that matters.

## The Pattern Across These Creators

The shared value is not that they all teach the same thing. They do not.

The value is that together they form a learning stack:

- CodeEmporium for systems structure;
- AI Coffee Break with Letitia for accessible AI orientation;
- Yannic Kilcher for paper-level AI depth;
- Sebastian Bubeck for frontier research framing;
- Acerola for graphics, optimization, taste, and technical storytelling.

That combination fits Julian’s actual work: not merely learning to code, but learning how to design systems that can explain themselves.
