# 03 — Learning Style: Systems First, Then Syntax

Julian’s learning style is not linear. It is recursive, project-driven, and pressure-tested.

A typical beginner path says: learn syntax, then learn tools, then build toy apps, then eventually study architecture.

Julian’s path is messier and more powerful: collide with an architectural problem, chase the concepts required to understand it, build a prototype, break the prototype, document the breakage, then turn the failure into a reusable rule.

This means learning often happens through friction. A concept becomes real when it has caused a failure.

Type systems are not just lecture material once they prevent a bad boundary.

Receipts are not just audit logs once an agent destroys work and there is no reliable reconstruction path.

Governance is not abstract once a codebase has too many places where authority is implied instead of explicit.

Projection-driven UI is not aesthetic once the frontend starts inventing state the backend should own.

This is why Julian’s work often produces docs, schemas, manifests, validators, and ledgers. Those are not bureaucracy for its own sake. They are compensating structures for complexity, memory, cognitive load, agent unreliability, and long-running project continuity.

The learning style has several recurring traits:

- learn through building, not passive consumption;
- keep returning to first principles when tools get weird;
- prefer concrete demonstrations over hand-wavy claims;
- distrust invisible state;
- convert lessons into rules, validators, and repeatable workflows;
- use writing as a thinking tool, not just as documentation after the fact;
- treat architecture as something that must survive tiredness, interruptions, and imperfect agents.

The result is not always fast in the moment. But it compounds.

Anigma taught lessons the expensive way.  
Rig is the cheaper lab where those lessons can be tested faster.  
The future product inherits the parts that survive.
