# 09 — Social / Short-Form Drafts

## Post 1

I learned Java around 2012 and took my first Swift courses around 2018.

The funny part is that the languages were less important than what they taught me.

Java taught me explicit structure.  
Swift taught me product craft.  
Broken projects taught me governance.

That last one was the expensive class.

## Post 2

YouTube can be a waste of time, but technical YouTube can also be a map.

The trick is not to stop at the video.

Use the video for vocabulary.  
Use docs for precision.  
Use papers for depth.  
Use source code for reality.  
Use your own project for consequences.

## Post 3

My actual software learning loop:

Find pain.  
Name the class of problem.  
Research the concept.  
Build a tiny proof.  
Document the failure.  
Turn the lesson into a validator, receipt, or architectural boundary.

It is not glamorous. It compounds.

## Post 4

A lot of my tooling looks overbuilt until you understand what it is compensating for:

interrupted work, unreliable agents, invisible state, cognitive load, failed refactors, lost changes, and architecture decisions nobody can reconstruct later.

Receipts are not decoration. They are memory armor.

## Post 5

I used to think the hard part was learning enough syntax.

Now I think the hard part is building systems that still make sense after you are tired, interrupted, overwhelmed, or working with an AI agent that confidently deletes the wrong thing.
