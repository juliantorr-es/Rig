# 01 — Origin Story: Java, Swift, and the Long Way Around

Julian did not begin this work by waking up one day and deciding to build governed AI tooling. The path started much earlier and much more normally: learning to code in Java around 2012.

Java mattered because it forced structure. It made programming feel like a system of named things: classes, methods, interfaces, inheritance, objects, types, files, packages. It was not always elegant, and it was not always fun, but it taught the basic grammar of software: state lives somewhere, behavior belongs somewhere, and if names are bad enough, the whole machine becomes a swamp.

That early Java period gave Julian a first model of code as organized responsibility. Even when the tools were clunky, the discipline stayed useful. Java made the invisible visible. It taught that programs are not magic; they are arrangements of contracts.

Swift entered later, through courses around 2018. That was a different door. Swift was not just another language. It carried the promise of modern app development, Apple-native UI, type safety, value semantics, and a design philosophy that felt closer to product craft. Where Java introduced the architecture of objects, Swift introduced a taste for expressive interfaces, native software, and the idea that a codebase could feel both strict and elegant.

The 2018 Swift courses were not just about syntax. They were a bridge into a different ecosystem: Apple platforms, SwiftUI later on, strong compiler feedback, structured APIs, and the realization that native software could be personal, refined, and deeply integrated with the machine.

The eventual shape of Anigma and Rig makes more sense with that history in mind.

Java contributed the instinct for explicit contracts.

Swift contributed the attraction to native systems, strong typing, and humane interfaces.

The years between them contributed scar tissue: learning that a language can teach concepts, but real software teaches consequences.

That is the quiet arc: from learning what a class is, to learning what an architecture costs, to building tools that make those costs visible before they bankrupt the project.
