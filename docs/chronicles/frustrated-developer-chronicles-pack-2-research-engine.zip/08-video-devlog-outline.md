# 08 — Video / Devlog Outline: How I Actually Learn Software Engineering

## Working Title

How I Learned to Research Like a Software Engineer

## Cold Open

“I did not learn software engineering by following one clean curriculum. I learned it by repeatedly building things too ambitious for my current skill level, getting humbled, and then turning the wound into architecture.”

## Section 1 — The Beginning

- Learned to code in Java around 2012.
- Java taught structure, naming, classes, objects, and explicit responsibility.
- It was not glamorous, but it created the first mental model for software as organized contracts.

## Section 2 — The Swift Turn

- Took first Swift courses around 2018.
- Swift made programming feel closer to product craft.
- Apple-native development introduced a different standard: strong APIs, polished interfaces, native integration, and the idea that software can feel designed.

## Section 3 — YouTube Was Not a Waste of Time

- YouTube became a serious learning surface.
- Valuable creators helped build vocabulary and intuition.
- The point was not to stop at videos. The point was to use them as a launchpad into docs, papers, and experiments.

Mention creator categories:

- systems explainers;
- AI paper walkthroughs;
- research explainers;
- graphics/performance educators;
- people who make difficult technical ideas feel navigable.

## Section 4 — My Research Loop

- Start with a practical pain.
- Ask what class of problem it belongs to.
- Find the concept.
- Study multiple explanations.
- Read primary sources when needed.
- Build a tiny proof.
- Convert the lesson into a rule, validator, receipt, or architecture boundary.

## Section 5 — Why Rig and Anigma Look So Weird

- They are not just apps.
- They are accumulated research habits turned into software.
- Receipts, validators, projections, ledgers, missions, and governance all come from trying to make complex work survivable.

## Section 6 — Advice to New Developers

- Do not confuse watching videos with learning, but do not dismiss video either.
- Use videos to get vocabulary.
- Use docs to get precision.
- Use source code to get reality.
- Use projects to get consequences.
- Write down what breaks.
- Convert repeated pain into tooling.

## Ending Line

“The point was never to know everything. The point was to build a system that helps me keep learning without losing the thread.”
