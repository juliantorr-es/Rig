# 04 — YouTube as Engineering School

For Julian, YouTube is not just entertainment or background noise. It is a working research surface.

Good technical YouTube does something textbooks and docs often do not: it gives shape, taste, pacing, visual intuition, and a sense of how experienced engineers think through a problem. It can turn a vague topic into a map. It can make the first pass less hostile. It can reveal which concepts are worth deeper study.

The best creators are not valuable because they replace documentation or papers. They are valuable because they help decide where to aim attention.

A strong video can provide:

- the first mental model;
- vocabulary for better searches;
- intuition for why a technique exists;
- a bridge from beginner explanation to primary sources;
- a way to compare competing approaches;
- an emotional reminder that hard systems are learnable.

The danger is that YouTube can become infinite grazing. Julian’s useful pattern is different: video creates orientation, then papers/docs/source code create depth, then local experiments create proof.

That workflow looks like this:

Watch for the model.  
Pause for the vocabulary.  
Search for the paper or implementation.  
Map it to the current project.  
Build a small proof.  
Write down the boundary.  
Turn the lesson into architecture.

This makes YouTube part of the research engine. Not the authority, but the ignition system.
