# Frustrated Developer Chronicles — Pack 2  
## The Research Engine

This companion pack is about the part of the story that is easy to miss from the outside: how Julian learns, researches, filters information, builds taste, and turns scattered technical curiosity into working systems.

The first pack was about the pain of building.  
This pack is about the method underneath the pain.

It covers:

- how Julian learned to code, starting with Java around 2012;
- how Swift entered the picture through courses around 2018;
- why YouTube became a serious technical learning surface, not just entertainment;
- which software engineering and AI educators became especially useful;
- how research turns into architecture, validators, receipts, and product doctrine;
- why Rig and Anigma are not random projects, but accumulated learning artifacts.

This is not a polished autobiography. It is source material: part memoir, part devlog, part creator bible, part proof of work.
