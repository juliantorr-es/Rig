# 06 — From Research to Architecture

Julian’s research does not stay in a notes folder. It mutates into architecture.

This is one of the main differences between ordinary technical curiosity and the way the work around Rig and Anigma has developed.

A topic enters as research:

- agent tool calling;
- deterministic validation;
- sandboxing;
- model benchmarking;
- runtime projections;
- governance gates;
- stream APIs;
- local-first workflows;
- zero-copy architecture;
- AI safety frameworks;
- evidence receipts;
- UX for complex systems.

Then it gets translated into a project primitive.

“Agents are unreliable” becomes proposal lifecycle governance.

“Context gets messy” becomes context assembly.

“Frontend state drifts” becomes projection authority.

“Build outputs are hard to interpret” becomes diagnostics and receipts.

“Research needs provenance” becomes source-backed docs and proof artifacts.

“LLMs call tools imperfectly” becomes deterministic decoding, validation, and routing.

“Learning is hard to resume after interruption” becomes ledgers, missions, and handoffs.

This is the real research loop:

Study the external concept.  
Extract the invariant.  
Name the local primitive.  
Write the contract.  
Add the validator.  
Generate the receipt.  
Use the result to guide the next slice.

The point is not to copy what other systems do. The point is to translate useful principles into a local architecture with its own rules.

That is why Rig matters.

Rig is not just a smaller tool. It is a research compression chamber. It lets Julian test Anigma-grade ideas in a simpler Python product before those ideas become part of the more ambitious native architecture.

In that sense, Rig is not a detour. It is a method.
