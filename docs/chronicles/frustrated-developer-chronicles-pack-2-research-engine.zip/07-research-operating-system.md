# 07 — The Research Operating System

The phrase “research operating system” fits Julian’s process because the research is not one activity. It is a stack.

At the top is curiosity: the messy human part. A question feels interesting, suspicious, urgent, annoying, or beautiful.

Below that is intake: videos, papers, docs, search results, transcripts, examples, source code, CLI output, and conversations.

Below that is synthesis: turning those inputs into notes, diagrams, schemas, architecture claims, and comparisons.

Below that is proof: demos, tests, validators, receipts, benchmark outputs, and reproducible artifacts.

Below that is governance: deciding what is trusted, what is advisory, what can mutate state, what must be blocked, and what needs review.

Below that is productization: turning the best surviving patterns into user-facing workflows.

The system is not perfect. It is sometimes exhausting. It can create too many docs, too many names, too many intermediate artifacts. But the instinct is right: when a project is cognitively heavy, the answer is not to trust memory harder. The answer is to externalize the process.

Julian’s research operating system externalizes:

- what was learned;
- where it came from;
- what it changed;
- what remains uncertain;
- what can be reproduced;
- what should be trusted;
- what an agent is allowed to do next.

That is why the work keeps returning to receipts, ledgers, validators, and projections. Those are not side quests. They are the nervous system.
